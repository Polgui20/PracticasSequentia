<html>
<?php  
header("Location: https://play.google.com/store/apps/details?id=com.unow.Sequentia", true, 301);  
exit();  
?> 