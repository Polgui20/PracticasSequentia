<html>
<?php  
header("Location: https://apps.apple.com/es/app/sequentia/id6448124358", true, 301);  
exit();  
?> 